# Parser PROCESADORES DEL LENGUAJE

## Alumnos
 * [Aitor Chordá](https://github.com/aitor422)
 * [Miguel Echenique](https://github.com/miguel96)

## Instrucciones
  Para compilar el fichero simplemente ejecute el make sin ningún argumento.
  Para ejecutar el escáner use a.out y como primer argumento el nombre del
  fichero de entrada en su defecto podrá utilizar la entrada estándar
